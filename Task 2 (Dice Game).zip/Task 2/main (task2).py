import random
import time

user1In = False
user2In = False

readUsers = open('Usernames')
readUserLines = readUsers.read()
readUsers.close()

user1Enter = 'MoffS001'
user2Enter = 'GanuS001'

attempts = 0

def password(userIn, UserNum, tries):
    userEnter = input("Enter " + UserNum + "'s Username: ")
    if userEnter in readUserLines:
        userIn = True
        print('Username was correct.')
        print(' ')
    else:
        print('The Username was incorrect, please try again.')
        tries += 1

    return userEnter, userIn, tries


while not user1In:
    runUserEnter = password(user1In, 'the first Player', attempts)
    user1Enter = runUserEnter[0]
    user1In = runUserEnter[1]
    attempts = runUserEnter[2]
    if attempts >= 3:
        print(' ' + '\nToo many attempts at entering the username! Please try again later.')
        exit()

attempts = 0

while not user2In:
    runUserEnter = password(user2In, 'the second Player', attempts)
    user2Enter = runUserEnter[0]
    user2In = runUserEnter[1]
    attempts = runUserEnter[2]
    if attempts >= 3:
        print(' ' + '\nToo many attempts at entering the username! Please try again later.')
        exit()

print('Welcome to the program ' + user1Enter + ' and ' + user2Enter + '!')

user1Score = 0
user2Score = 0

def roll(username, userscore):
    randomNumber = random.randint(1, 6)

    userscore += randomNumber

    print(username, 'has rolled a', str(randomNumber)+'!','Their score is now:',userscore)
    print(' ')

    return userscore

def writeToFile(userName, userScore):
    with open("hiscores.txt") as load_file:
        HighscoreList = [tuple(line.split()) for line in load_file]

    winnerInfo = (userName, userScore)

    index = 0

    for i in HighscoreList:
        score = HighscoreList[index] #  Score in file.

        if winnerInfo[1] > int(score[1]):
            HighscoreList.insert(index, winnerInfo)  # updates score
            HighscoreList.pop(5) #  removes lowest score
            break  # make loop stop when it finds smaller

        index += 1

    openNew = open("hiscores.txt", "w")

    for o in HighscoreList:
        str1 = o[0]  # make player a string
        num1 = o[1]
        openNew.write(str1)
        openNew.write(" ")
        openNew.write(str(num1))
        openNew.write("\n")

    openNew.close()

rounds = 0

while rounds < 5 or user1Score == user2Score:
    rounds += 1

    user1Score = roll(user1Enter, user1Score)

    user2Score = roll(user2Enter, user2Score)

if user1Score > user2Score:
    print(user1Enter, 'has won the game with a score of:', str(user1Score) + '!')
    writeToFile(user1Enter, user1Score)

if user2Score > user1Score:
    print(user2Enter, 'has won the game with a score of:', str(user2Score) + '!')
    writeToFile(user2Enter, user2Score)


with open("hiscores.txt") as load_file:
    HighscoreList = [tuple(line.split()) for line in load_file]

index = 0


with open("hiscores.txt") as load_file:
    HighscoreList2 = [tuple(line.split()) for line in load_file]

load_file.close()

print(' ')
print('//////////////////////')
print("Highscores:")
for i in HighscoreList2:
    player = i[0]
    number = i[1]
    print(player, "with a score of:", number +'.')
print('//////////////////////')
print(' ')
