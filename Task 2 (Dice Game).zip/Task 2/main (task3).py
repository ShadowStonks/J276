import random
import time

user1In = False
user2In = False

readUsers = open('Usernames')
readUserLines = readUsers.read()
readUsers.close()

user1Enter = ''
user2Enter = ''

attempts = 0


def password(userIn, UserNum, tries):
    userEnter = input("Enter " + UserNum + "'s Username: ")
    if userEnter in readUserLines:
        userIn = True
        print('Username was correct.')
        print(' ')
    else:
        print('The Username was incorrect, please try again.')
        tries += 1

    return userEnter, userIn, tries


while not user1In:
    runUserEnter = password(user1In, 'the first Player', attempts)
    user1Enter = runUserEnter[0]
    user1In = runUserEnter[1]
    attempts = runUserEnter[2]
    if attempts >= 3:
        print(' ' + '\nToo many attempts at entering the username! Please try again later.')
        exit()

attempts = 0

while not user2In:
    runUserEnter = password(user2In, 'the second Player', attempts)
    user2Enter = runUserEnter[0]
    user2In = runUserEnter[1]
    attempts = runUserEnter[2]
    if attempts >= 3:
        print(' ' + '\nToo many attempts at entering the username! Please try again later.')
        exit()

print('Welcome to the program ' + user1Enter + ' and ' + user2Enter + '!')

with open("hiscores.txt") as load_file:
    HighscoreList = [tuple(line.split()) for line in load_file]

load_file.close()

print(' ')
print('//////////////////////')
print("Top Highscores:")
for i in HighscoreList:
    player = i[0]
    number = i[1]
    print(player, "with", number, "cards.")
print('//////////////////////')
print(' ')

time.sleep(2)

r1 = ('red', 1)
r2 = ('red', 2)
r3 = ('red', 3)
r4 = ('red', 4)
r5 = ('red', 5)
r6 = ('red', 6)
r7 = ('red', 7)
r8 = ('red', 8)
r9 = ('red', 9)
r10 = ('red', 10)

b1 = ('black', 1)
b2 = ('black', 2)
b3 = ('black', 3)
b4 = ('black', 4)
b5 = ('black', 5)
b6 = ('black', 6)
b7 = ('black', 7)
b8 = ('black', 8)
b9 = ('black', 9)
b10 = ('black', 10)

y1 = ('yellow', 1)
y2 = ('yellow', 2)
y3 = ('yellow', 3)
y4 = ('yellow', 4)
y5 = ('yellow', 5)
y6 = ('yellow', 6)
y7 = ('yellow', 7)
y8 = ('yellow', 8)
y9 = ('yellow', 9)
y10 = ('yellow', 10)

main_list = [r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, y1, y2, y3, y4, y5, y6,
             y7, y8, y9, y10]

random.shuffle(main_list)

cardAmm = 30

index = 0

Player1 = True
Player1Card = ()
player1Win = 0
player1Ammount = 0
player1Cards = []

Player2 = False
Player2Card = ()
player2Win = 0
player2Ammount = 0
player2Cards = []


def playerWinner(username, pW, pA, pC):
    pW += 1
    pA += 2
    print(username + ' has won this round!')
    print(' ')

    pC.append(Player1Card)
    pC.append(Player2Card)

    time.sleep(2)

    return pW, pA, pC


while cardAmm > 0:
    if Player1:
        Player1 = False
        Player2 = True

        Player1Card = main_list[index]
        index += 1

        input(user1Enter + ', press "enter" to take the next card: ')

        print(' ')

        print(user1Enter + "'s card is " + str(Player1Card[0]) + ', ' + str(Player1Card[1]) + '.')
        print(' ')

        cardAmm -= 1
    if Player2:
        Player2 = False
        Player1 = True

        Player2Card = main_list[index]
        index += 1

        input(user2Enter + ', press "enter" to take the next card: ')

        print(' ')

        print(user2Enter + "'s card is " + str(Player2Card[0]) + ', ' + str(Player2Card[1]) + '.')

        print(' ')

        cardAmm -= 1

    if Player1Card[0] == Player2Card[0]:
        if Player1Card[1] > Player2Card[1]:
            winner = playerWinner(user1Enter, player1Win, player1Ammount, player1Cards)

            player1Win = winner[0]
            player1Ammount = winner[1]
            player1Cards = winner[2]

        if Player2Card[1] > Player1Card[1]:
            winner = playerWinner(user2Enter, player2Win, player2Ammount, player2Cards)

            player2Win = winner[0]
            player2Ammount = winner[1]
            player2Cards = winner[2]

    if Player1Card[0] == 'red' and Player2Card[0] == 'black':
        winner = playerWinner(user1Enter, player1Win, player1Ammount, player1Cards)

        player1Win = winner[0]
        player1Ammount = winner[1]
        player1Cards = winner[2]

    if Player1Card[0] == 'yellow' and Player2Card[0] == 'red':
        winner = playerWinner(user1Enter, player1Win, player1Ammount, player1Cards)

        player1Win = winner[0]
        player1Ammount = winner[1]
        player1Cards = winner[2]

    if Player1Card[0] == 'black' and Player2Card[0] == 'yellow':
        winner = playerWinner(user1Enter, player1Win, player1Ammount, player1Cards)

        player1Win = winner[0]
        player1Ammount = winner[1]
        player1Cards = winner[2]

    if Player2Card[0] == 'red' and Player1Card[0] == 'black':
        winner = playerWinner(user2Enter, player2Win, player2Ammount, player2Cards)

        player2Win = winner[0]
        player2Ammount = winner[1]
        player2Cards = winner[2]

    if Player2Card[0] == 'yellow' and Player1Card[0] == 'red':
        winner = playerWinner(user2Enter, player2Win, player2Ammount, player2Cards)

        player2Win = winner[0]
        player2Ammount = winner[1]
        player2Cards = winner[2]

    if Player2Card[0] == 'black' and Player1Card[0] == 'yellow':
        winner = playerWinner(user2Enter, player2Win, player2Ammount, player2Cards)

        player2Win = winner[0]
        player2Ammount = winner[1]
        player2Cards = winner[2]

if player2Win > player1Win:
    print(user2Enter + ' wins with a score of: ' + str(player2Win) + ' and ' + str(player2Ammount) + ' cards.')
    print(' ')
    print(user2Enter + ' owned these cards: ')
    for i in player2Cards:
        print(i[0] + ', ' + str(i[1]))
    write_file = open('previous winner.txt', 'w')
    write_file.write(user2Enter)
    write_file.close()
    write_file2 = open('previous winner ammount.txt', 'w')
    write_file2.write(str(player2Ammount))
    write_file2.close()

    with open("hiscores.txt") as load_file:
        HighscoreList = [tuple(line.split()) for line in load_file]

    index = 0

    winner = (user2Enter, player2Ammount)

    for i in HighscoreList:
        score = HighscoreList[index]  # Score in file.

        if winner[1] > int(score[1]):
            HighscoreList.insert(index, winner)  # updates score
            HighscoreList.pop(5)  # removes lowest score
            break  # make loop stop when it finds smaller

        index += 1

    openNew = open("hiscores.txt", "w")

    for o in HighscoreList:
        str1 = o[0]  # make player a string
        num1 = o[1]
        openNew.write(str1)
        openNew.write(" ")
        openNew.write(str(num1))
        openNew.write("\n")

    openNew.close()

if player1Win > player2Win:
    print(user1Enter + ' wins with a score of: ' + str(player1Win) + ' and had ' + str(player1Ammount) + ' cards.')
    print(' ')
    print(user1Enter + ' owned these cards: ')
    for i in player1Cards:
        print(i[0] + ', ' + str(i[1]))
    write_file = open('previous winner.txt', 'w')
    write_file.write(user1Enter)
    write_file.close()
    write_file2 = open('previous winner ammount.txt', 'w')
    write_file2.write(str(player1Ammount))
    write_file2.close()

    with open("hiscores.txt") as load_file:
        HighscoreList = [tuple(line.split()) for line in load_file]

    index = 0

    winner = (user1Enter, player1Ammount)

    for i in HighscoreList:
        score = HighscoreList[index]  # Score in file.

        if winner[1] > int(score[1]):
            HighscoreList.insert(index, winner)  # updates score
            HighscoreList.pop(5)  # removes lowest score
            break  # make loop stop when it finds smaller

        index += 1

    openNew = open("hiscores.txt", "w")

    for o in HighscoreList:
        str1 = o[0]  # make player a string
        num1 = o[1]
        openNew.write(str1)
        openNew.write(" ")
        openNew.write(str(num1))
        openNew.write("\n")

    openNew.close()

with open("hiscores.txt") as load_file:
    HighscoreList = [tuple(line.split()) for line in load_file]

load_file.close()

print(' ')
print('//////////////////////')
print("Updated Highscores:")
for i in HighscoreList:
    player = i[0]
    number = i[1]
    print(player, "with", number, "cards.")
print('//////////////////////')
print(' ')

time.sleep(2)
