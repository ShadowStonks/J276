import random
import time

user1In = False
user2In = False

readUsers = open('Usernames')
readUserLines = readUsers.read()
readUsers.close()

user1Enter = ''

attempts = 0


def password(userIn, UserNum, tries):
    userEnter = input("Enter " + UserNum + "'s Username: ")
    if userEnter in readUserLines:
        userIn = True
        print('Username was correct.')
        print(' ')
    else:
        print('The Username was incorrect, please try again.')
        tries += 1

    return userEnter, userIn, tries


while not user1In:
    runUserEnter = password(user1In, 'the first Player', attempts)
    user1Enter = runUserEnter[0]
    user1In = runUserEnter[1]
    attempts = runUserEnter[2]
    if attempts >= 3:
        print(' ' + '\nToo many attempts at entering the username! Please try again later.')
        exit()

print('Welcome to the program ' + user1Enter + '!')


def artistAndSongFromList(i):
    indexOfSlash = (i.index('/'))  # Find where the character '/'
    lengthOfList = len(i)  # Find length of the artist and song name (including /)
    songTuple = (i[0:indexOfSlash])  # Isolate where the song name is in the tuple
    artistTuple = (i[(indexOfSlash + 1):lengthOfList])  # Isolate where the artist name is in the tuple
    artistStr = str()

    for i in artistTuple:
        artistStr += str(i + ' ')  # Makes artist name a string

    artistStr = artistStr[:-1]  # removes space at end of string

    return songTuple, artistStr


def writeToFile(userName, userScore):
    with open("hiscores.txt") as load_file:
        HighscoreList = [tuple(line.split()) for line in load_file]

    winnerInfo = (userName, userScore)

    index = 0

    for i in HighscoreList:
        score = HighscoreList[index]  # Score in file.

        if winnerInfo[1] > int(score[1]):
            HighscoreList.insert(index, winnerInfo)  # updates score
            HighscoreList.pop(5)  # removes lowest score
            break  # make loop stop when it finds smaller

        index += 1

    openNew = open("hiscores.txt", "w")

    for o in HighscoreList:
        str1 = o[0]  # make player a string
        num1 = o[1]
        openNew.write(str1)
        openNew.write(" ")
        openNew.write(str(num1))
        openNew.write("\n")

    openNew.close()


def mainGame():
    with open("Music and artists") as openFile:
        mainList = [tuple(line.split()) for line in openFile]  # Splits each line into tuple and adds tuple to mainList

    random.shuffle(mainList)

    index = 0

    user1Score = 0

    chosenLine = mainList[index]

    while True:
        getArtistAndSong = artistAndSongFromList(chosenLine)
        songTup = getArtistAndSong[0]
        artist = getArtistAndSong[1]
        letters = str()

        songStr = str()
        for i in songTup:
            songStr += str(i + ' ')  # Makes song name a string
            letters += (i[0] + ', ')  # Adds first of word to a string

        song = songStr[:-1]  # removes space at end of string
        letters = letters[:-2]  # removes space and comma at end of string

        print(
            'The name of the artist is: ' + artist + " and the first character of each word in the song are: " + letters + '.')
        guess = input('Enter your guess for the song name: ')

        guesses = 0

        if guess == song:
            user1Score += 3
            print('Correct! Your current score is: ' + str(user1Score))
            time.sleep(2)
        if guess != song:
            print('Incorrect')
            guesses += 1
            guess = input('Enter your guess for the song name: ')
            if guess != song:
                print('Unlucky you failed! Your final score was: ' + str(user1Score))
                writeToFile(user1Enter, user1Score)
                time.sleep(5)
                break
            else:
                user1Score += 1
                print('Correct! Your current score is: ' + str(user1Score))
                time.sleep(2)

        index += 1

        if index == 6:  # CHANGE NUMBER TO HOWEVER MANY SONGS ARE IN YOUR FILE
            index = 0  # Sets index back to 0
            random.shuffle(mainList)  # Shuffles the list again

        chosenLine = mainList[index]

    with open("hiscores.txt") as load_file:
        HighscoreList2 = [tuple(line.split()) for line in load_file]

    print(' ')
    print('//////////////////////')
    print("Highscores:")
    for i in HighscoreList2:
        player = i[0]
        number = i[1]
        print(player, "with a score of:", number + '.')
    print('//////////////////////')


mainGame()
